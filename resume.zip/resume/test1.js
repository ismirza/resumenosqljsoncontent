var jcontent = {
  "firstName": "Ibrokhim",
  "lastName": "Mirzakhonov",
  "job": "Web Developer at Epic",
  "college": "Point Park",
  "grad": "December 2020",
}
var output = document.getElementById('output');
output.innerHTML = jcontent.firstName + ' ' + jcontent.lastName + '. Currently work as '
+ jcontent.job + '. I go to ' + jcontent.college + ' and graduate in ' + jcontent.grad;
